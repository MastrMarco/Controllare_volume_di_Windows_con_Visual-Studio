﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.valSound = New System.Windows.Forms.Label()
        Me.TrackBarSound = New System.Windows.Forms.TrackBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.TrackBarSound, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'valSound
        '
        Me.valSound.AutoSize = True
        Me.valSound.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.valSound.Location = New System.Drawing.Point(365, 22)
        Me.valSound.Name = "valSound"
        Me.valSound.Size = New System.Drawing.Size(83, 18)
        Me.valSound.TabIndex = 0
        Me.valSound.Text = "Sound%"
        '
        'TrackBarSound
        '
        Me.TrackBarSound.Location = New System.Drawing.Point(248, 117)
        Me.TrackBarSound.Maximum = 100
        Me.TrackBarSound.Name = "TrackBarSound"
        Me.TrackBarSound.Size = New System.Drawing.Size(338, 45)
        Me.TrackBarSound.TabIndex = 1
        Me.TrackBarSound.TickFrequency = 0
        Me.TrackBarSound.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Timer1
        '
        Me.Timer1.Interval = 30
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 245)
        Me.Controls.Add(Me.TrackBarSound)
        Me.Controls.Add(Me.valSound)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.TrackBarSound, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents valSound As Label
    Friend WithEvents TrackBarSound As TrackBar
    Friend WithEvents Timer1 As Timer
End Class
