﻿Imports CoreAudioApi
Public Class Form1

    Dim Svol As Integer = 0

    Private Function setvol() As Integer
        Dim devenum As New MMDeviceEnumerator
        Dim device As MMDevice = devenum.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia)
        device.AudioEndpointVolume.MasterVolumeLevelScalar = Svol / 100.0F
    End Function

    Private Function getvol() As Integer
        Dim mastermin As Integer = 0
        Dim devenum As New MMDeviceEnumerator
        Dim device As MMDevice = devenum.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia)
        Dim vol As Integer = 0

        With device.AudioEndpointVolume
            vol = CInt(.MasterVolumeLevelScalar * 100)
            If vol < mastermin Then
                vol = mastermin / 100
            End If
        End With
        Return vol
    End Function
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TrackBarSound.Value = getvol()
        Timer1.Start()

        valSound.Text = TrackBarSound.Value.ToString & "%"
    End Sub

    Private Sub TrackBarSound_Scroll(sender As Object, e As EventArgs) Handles TrackBarSound.Scroll
        Svol = TrackBarSound.Value
        If Svol < 0 Then
            Svol = 0
        ElseIf Svol > 100 Then
            Svol = 100
        End If
        setvol()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim v As Integer = getvol()
        If TrackBarSound.Value <> v Then
            TrackBarSound.Value = v
        End If
        valSound.Text = TrackBarSound.Value.ToString & "%"
    End Sub
End Class
